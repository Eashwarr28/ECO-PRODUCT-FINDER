package com.example.eco_product_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
