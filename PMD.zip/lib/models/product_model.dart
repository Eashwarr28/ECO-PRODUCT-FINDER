class ProductModel {
  String id;
  String name;
  String description;
  String category;
  double price;
  String ecoCertification;
  String ecoRating; // A, B, C, D
  List<String> ecoTags;
  bool isSaved;
  DateTime createdAt;

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.price,
    required this.ecoCertification,
    this.ecoRating = 'B',
    this.ecoTags = const [],
    this.isSaved = false,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'category': category,
      'price': price,
      'ecoCertification': ecoCertification,
      'ecoRating': ecoRating,
      'ecoTags': ecoTags,
      'isSaved': isSaved,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory ProductModel.fromMap(String id, Map<String, dynamic> map) {
    return ProductModel(
      id: id,
      name: map['name'] ?? '',
      description: map['description'] ?? '',
      category: map['category'] ?? '',
      price: (map['price'] ?? 0).toDouble(),
      ecoCertification: map['ecoCertification'] ?? 'Recyclable',
      ecoRating: map['ecoRating'] ?? 'B',
      ecoTags: List<String>.from(map['ecoTags'] ?? []),
      isSaved: map['isSaved'] ?? false,
      createdAt: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt'].toString()) ?? DateTime.now()
          : DateTime.now(),
    );
  }
}
