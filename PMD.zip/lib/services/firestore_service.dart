import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/product_model.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String get userId => _auth.currentUser!.uid;

  CollectionReference get _productsRef =>
      _firestore.collection('users').doc(userId).collection('products');

  // CREATE
  Future<void> addProduct(ProductModel product) async {
    await _productsRef.doc(product.id).set(product.toMap());
  }

  // READ ALL (real-time stream)
  Stream<List<ProductModel>> getProducts() {
    return _productsRef.orderBy('createdAt', descending: true).snapshots().map(
          (snapshot) => snapshot.docs
              .map(
                (doc) => ProductModel.fromMap(
                  doc.id,
                  doc.data() as Map<String, dynamic>,
                ),
              )
              .toList(),
        );
  }

  // READ SAVED (real-time stream)
  Stream<List<ProductModel>> getSavedProducts() {
    return _productsRef.where('isSaved', isEqualTo: true).snapshots().map(
          (snapshot) => snapshot.docs
              .map(
                (doc) => ProductModel.fromMap(
                  doc.id,
                  doc.data() as Map<String, dynamic>,
                ),
              )
              .toList(),
        );
  }

  // READ by CATEGORY
  Stream<List<ProductModel>> getProductsByCategory(String category) {
    return _productsRef.where('category', isEqualTo: category).snapshots().map(
          (snapshot) => snapshot.docs
              .map(
                (doc) => ProductModel.fromMap(
                  doc.id,
                  doc.data() as Map<String, dynamic>,
                ),
              )
              .toList(),
        );
  }

// READ by ECO RATING (A, B, C, or D) - For advanced filtering
  Stream<List<ProductModel>> getProductsByEcoRating(String rating) {
    return _productsRef
        .where('ecoRating', isEqualTo: rating.toUpperCase())
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map(
                (doc) => ProductModel.fromMap(
                  doc.id,
                  doc.data() as Map<String, dynamic>,
                ),
              )
              .toList(),
        );
  }

  // UPDATE
  Future<void> updateProduct(ProductModel product) async {
    await _productsRef.doc(product.id).update(product.toMap());
  }

  // TOGGLE SAVED
  Future<void> toggleSaved(String id, bool currentStatus) async {
    await _productsRef.doc(id).update({'isSaved': !currentStatus});
  }

  // DELETE
  Future<void> deleteProduct(String id) async {
    await _productsRef.doc(id).delete();
  }

  // GET STATS
  Future<Map<String, int>> getStats() async {
    final snapshot = await _productsRef.get();
    final products = snapshot.docs
        .map(
          (doc) =>
              ProductModel.fromMap(doc.id, doc.data() as Map<String, dynamic>),
        )
        .toList();
    return {
      'total': products.length,
      'saved': products.where((p) => p.isSaved).length,
    };
  }
}
