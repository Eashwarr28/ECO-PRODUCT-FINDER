import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: "AIzaSyDF8g8ygpoQ1rI1z_5RuNlTe_S5RsHsaqc",
    authDomain: "eco-product-finder-6e4b7.firebaseapp.com",
    projectId: "eco-product-finder-6e4b7",
    storageBucket: "eco-product-finder-6e4b7.firebasestorage.app",
    messagingSenderId: "616108041720",
    appId: "1:616108041720:web:7732f259bb8678ccdba20d",
  );
}
