import 'package:flutter/material.dart';
import 'package:confetti/confetti.dart';
import '../models/product_model.dart';
import '../services/firestore_service.dart';

class AddEditProductScreen extends StatefulWidget {
  final ProductModel? product;

  const AddEditProductScreen({super.key, this.product});

  @override
  State<AddEditProductScreen> createState() => _AddEditProductScreenState();
}

class _AddEditProductScreenState extends State<AddEditProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();

  String _selectedCategory = 'Household';
  String _selectedCertification = 'Recyclable';
  String _selectedRating = 'B';
  bool _isSaving = false;

  // Confetti Controller
  late ConfettiController _confettiController;

  final List<String> _categories = [
    'Household',
    'Personal Care',
    'Food & Beverage',
    'Fashion',
    'Electronics',
  ];

  final List<String> _certifications = [
    'Recyclable',
    'Biodegradable',
    'Compostable',
    'Plastic-Free',
    'Organic',
  ];

  final List<String> _ratings = ['A', 'B', 'C', 'D'];

  final Map<String, Color> _ratingColors = {
    'A': Colors.green,
    'B': Colors.lightGreen,
    'C': Colors.orange,
    'D': Colors.red,
  };

  final Map<String, String> _ratingLabels = {
    'A': 'Excellent',
    'B': 'Good',
    'C': 'Average',
    'D': 'Poor',
  };

  @override
  void initState() {
    super.initState();
    // Initialize Confetti Controller
    _confettiController = ConfettiController(
      duration: const Duration(seconds: 2),
    );

    if (widget.product != null) {
      final p = widget.product!;
      _nameController.text = p.name;
      _descriptionController.text = p.description;
      _priceController.text = p.price.toString();
      _selectedCategory = p.category;
      _selectedCertification = p.ecoCertification;
      _selectedRating = p.ecoRating;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _confettiController.dispose();
    super.dispose();
  }

  bool get isEditing => widget.product != null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Product' : 'Add Product'),
        backgroundColor: const Color(0xFF2E7D32),
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Product Name
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Product Name *',
                    prefixIcon: Icon(Icons.shopping_bag_outlined),
                  ),
                  textCapitalization: TextCapitalization.words,
                  validator: (v) => v == null || v.trim().isEmpty
                      ? 'Product name is required'
                      : null,
                ),
                const SizedBox(height: 16),

                // Category
                DropdownButtonFormField<String>(
                  value: _selectedCategory,
                  decoration: const InputDecoration(
                    labelText: 'Category *',
                    prefixIcon: Icon(Icons.category_outlined),
                  ),
                  items: _categories
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedCategory = v!),
                ),
                const SizedBox(height: 16),

                // Eco Certification
                DropdownButtonFormField<String>(
                  value: _selectedCertification,
                  decoration: const InputDecoration(
                    labelText: 'Eco Certification *',
                    prefixIcon: Icon(Icons.verified_outlined),
                  ),
                  items: _certifications
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedCertification = v!),
                ),
                const SizedBox(height: 16),

                // Price
                TextFormField(
                  controller: _priceController,
                  decoration: const InputDecoration(
                    labelText: 'Price (RM) *',
                    prefixIcon: Icon(Icons.attach_money),
                  ),
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  validator: (v) {
                    if (v == null || v.isEmpty) return 'Price is required';
                    if (double.tryParse(v) == null)
                      return 'Enter a valid price';
                    if (double.parse(v) < 0) return 'Price cannot be negative';
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Description
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Description *',
                    prefixIcon: Icon(Icons.description_outlined),
                    alignLabelWithHint: true,
                  ),
                  maxLines: 3,
                  textCapitalization: TextCapitalization.sentences,
                  validator: (v) => v == null || v.trim().isEmpty
                      ? 'Description is required'
                      : null,
                ),
                const SizedBox(height: 20),

                // Eco Rating selector
                const Text(
                  'Eco Rating',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: _ratings.map((rating) {
                    final isSelected = _selectedRating == rating;
                    final color = _ratingColors[rating]!;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _selectedRating = rating),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: isSelected ? color : color.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color:
                                  isSelected ? color : color.withOpacity(0.3),
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: Column(
                            children: [
                              Text(
                                rating,
                                style: TextStyle(
                                  color: isSelected ? Colors.white : color,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                              Text(
                                _ratingLabels[rating]!,
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.white70
                                      : color.withOpacity(0.7),
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 32),

                // Save button
                SizedBox(
                  height: 52,
                  child: ElevatedButton(
                    onPressed: _isSaving ? null : _saveProduct,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2E7D32),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: _isSaving
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            isEditing ? 'Update Product' : 'Add Product',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),

          // Confetti Widget - positioned at the top
          Align(
            alignment: Alignment.topCenter,
            child: ConfettiWidget(
              confettiController: _confettiController,
              blastDirectionality: BlastDirectionality.explosive,
              emissionFrequency: 0.05,
              numberOfParticles: 30,
              gravity: 0.2,
              colors: const [
                Colors.green,
                Colors.lightGreen,
                Colors.greenAccent,
                Color(0xFF2E7D32),
                Colors.yellow,
              ],
              strokeWidth: 2,
              strokeColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _saveProduct() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    try {
      final firestoreService = FirestoreService();
      final product = ProductModel(
        id: widget.product?.id ??
            DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        category: _selectedCategory,
        price: double.parse(_priceController.text.trim()),
        ecoCertification: _selectedCertification,
        ecoRating: _selectedRating,
        isSaved: widget.product?.isSaved ?? false,
        createdAt: widget.product?.createdAt ?? DateTime.now(),
      );

      if (isEditing) {
        await firestoreService.updateProduct(product);
      } else {
        await firestoreService.addProduct(product);
      }

      // 🎉 PLAY CONFETTI ANIMATION 🎉
      _confettiController.play();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              isEditing ? '🎉 Product updated!' : '🎉 Product added!',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            backgroundColor: const Color(0xFF2E7D32),
            duration: const Duration(seconds: 2),
          ),
        );

        // Wait for confetti and pop back
        await Future.delayed(const Duration(milliseconds: 800));
        if (mounted) {
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }
}
